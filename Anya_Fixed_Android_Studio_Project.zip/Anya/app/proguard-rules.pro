# Gson / reflection-free JSON is used via JsonObject, but keep attributes for safety
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn okhttp3.**
-dontwarn okio.**
# Tink (used by security-crypto) optional deps
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**
