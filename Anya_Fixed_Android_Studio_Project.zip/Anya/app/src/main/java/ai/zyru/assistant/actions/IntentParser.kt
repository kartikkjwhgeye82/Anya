package ai.zyru.assistant.actions

import com.google.gson.JsonParser

data class PhoneIntent(val action: String, val params: Map<String, String>)

data class ParsedReply(val text: String, val intents: List<PhoneIntent>)

object IntentParser {

    private val marker = Regex("\\[INTENT:\\s*(\\{.*?\\})\\s*\\]", RegexOption.DOT_MATCHES_ALL)
    private const val MAX_INTENTS = 3

    fun extract(reply: String): ParsedReply {
        val intents = mutableListOf<PhoneIntent>()
        for (m in marker.findAll(reply)) {
            try {
                val obj = JsonParser.parseString(m.groupValues[1]).asJsonObject
                val action = obj.get("action")?.asString ?: continue
                val params = obj.entrySet()
                    .filter { it.key != "action" && it.value.isJsonPrimitive }
                    .associate { it.key to it.value.asString }
                intents.add(PhoneIntent(action, params))
            } catch (e: Exception) {
                // malformed marker: ignore it
            }
        }
        val clean = marker.replace(reply, "")
            .replace(Regex("\\n{3,}"), "\n\n")
            .trim()
        return ParsedReply(clean, intents.take(MAX_INTENTS))
    }
}
