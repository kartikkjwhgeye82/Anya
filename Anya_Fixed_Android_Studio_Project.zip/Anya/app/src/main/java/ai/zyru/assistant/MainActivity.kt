package ai.zyru.assistant

import ai.zyru.assistant.data.AnyaSettings
import ai.zyru.assistant.ui.theme.AnyaTheme
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

class MainActivity : ComponentActivity() {

    private val viewModel: AnyaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Show over the lock screen and wake the display (also declared in the manifest for API 27+).
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        setContent {
            AnyaTheme {
                AnyaAppScreen(viewModel)
            }
        }
    }
}

private fun hasPermission(context: android.content.Context, permission: String) =
    ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnyaAppScreen(viewModel: AnyaViewModel) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    var inputMessage by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    var pendingSettings by remember { mutableStateOf<AnyaSettings?>(null) }

    // Mic permission for the orb / mic button
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) viewModel.toggleListening()
        else Toast.makeText(context, "Microphone permission is required for voice.", Toast.LENGTH_LONG).show()
    }

    // Permissions needed by settings toggles (mic for always-active, notifications for care check-ins)
    val settingsPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        val pending = pendingSettings
        pendingSettings = null
        if (pending != null) {
            val micOk = hasPermission(context, Manifest.permission.RECORD_AUDIO)
            val notifOk = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
                hasPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            viewModel.saveSettings(
                pending.copy(
                    alwaysActive = pending.alwaysActive && micOk,
                    careNotifications = pending.careNotifications && notifOk
                )
            )
        }
    }

    fun onMicTap() {
        if (hasPermission(context, Manifest.permission.RECORD_AUDIO)) viewModel.toggleListening()
        else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    fun trySaveSettings(draft: AnyaSettings) {
        var s = draft
        if (s.floatingOrb && !Settings.canDrawOverlays(context)) {
            Toast.makeText(
                context,
                "Allow \"Display over other apps\" for Anya, then turn on the floating orb again.",
                Toast.LENGTH_LONG
            ).show()
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
            )
            s = s.copy(floatingOrb = false)
        }
        val needed = mutableListOf<String>()
        if (s.alwaysActive && !hasPermission(context, Manifest.permission.RECORD_AUDIO)) {
            needed += Manifest.permission.RECORD_AUDIO
        }
        if (s.careNotifications && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !hasPermission(context, Manifest.permission.POST_NOTIFICATIONS)
        ) {
            needed += Manifest.permission.POST_NOTIFICATIONS
        }
        if (needed.isEmpty()) {
            viewModel.saveSettings(s)
        } else {
            pendingSettings = s
            settingsPermLauncher.launch(needed.toTypedArray())
        }
    }

    // First launch: ask for the API key. Resume the always-active loop if it was enabled.
    LaunchedEffect(Unit) {
        if (uiState.settings.apiKey.isBlank()) showSettings = true
        if (uiState.settings.alwaysActive && hasPermission(context, Manifest.permission.RECORD_AUDIO)) {
            viewModel.resumeAlwaysActive()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "ANYA",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00F0FF),
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 2.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = when {
                                uiState.isListening -> "· LISTENING"
                                uiState.isThinking -> "· THINKING"
                                uiState.isSpeaking -> "· SPEAKING"
                                else -> "· READY"
                            },
                            color = if (uiState.isListening) Color(0xFF00F0FF) else Color(0xFF38BDF8),
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color(0xFF38BDF8))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF050811))
            )
        },
        containerColor = Color(0xFF050811)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(220.dp)
                    .clip(CircleShape)
                    .clickable { onMicTap() },
                contentAlignment = Alignment.Center
            ) {
                AnyaOrb(
                    isListening = uiState.isListening,
                    isThinking = uiState.isThinking,
                    level = uiState.audioLevel
                )
            }

            AudioWaveform(
                isActive = uiState.isListening || uiState.isSpeaking,
                isListening = uiState.isListening,
                level = uiState.audioLevel
            )

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                reverseLayout = true
            ) {
                items(uiState.messages.asReversed(), key = { it.id }) { message ->
                    ChatBubble(message)
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextField(
                    value = inputMessage,
                    onValueChange = { inputMessage = it },
                    placeholder = { Text("Ask Anya in English or Hindi...", color = Color.Gray, fontSize = 14.sp) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = {
                        if (inputMessage.isNotBlank()) {
                            viewModel.sendMessage(inputMessage)
                            inputMessage = ""
                        }
                    }),
                    modifier = Modifier.weight(1f),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFF0E1A2F),
                        unfocusedContainerColor = Color(0xFF0E1A2F),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    shape = RoundedCornerShape(24.dp)
                )

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = { onMicTap() },
                    modifier = Modifier
                        .size(48.dp)
                        .background(if (uiState.isListening) Color(0xFF00F0FF) else Color(0xFF0284C7), CircleShape)
                ) {
                    Icon(
                        if (uiState.isListening) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Voice input",
                        tint = if (uiState.isListening) Color.Black else Color.White
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                IconButton(
                    onClick = {
                        if (inputMessage.isNotBlank()) {
                            viewModel.sendMessage(inputMessage)
                            inputMessage = ""
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .background(Color(0xFF0E223D), CircleShape)
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Send",
                        tint = Color(0xFF38BDF8)
                    )
                }
            }
        }
    }

    if (showSettings) {
        SettingsDialog(
            initial = uiState.settings,
            onDismiss = { showSettings = false },
            onSave = { draft ->
                showSettings = false
                trySaveSettings(draft)
            }
        )
    }
}

@Composable
private fun SettingsDialog(
    initial: AnyaSettings,
    onDismiss: () -> Unit,
    onSave: (AnyaSettings) -> Unit
) {
    var draft by remember { mutableStateOf(initial) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF0E1A2F),
        title = { Text("Settings", color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = draft.apiKey,
                    onValueChange = { draft = draft.copy(apiKey = it) },
                    label = { Text("Gemini API key") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "Free key: aistudio.google.com/apikey (stored encrypted on this phone)",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                )

                OutlinedTextField(
                    value = draft.model,
                    onValueChange = { draft = draft.copy(model = it) },
                    label = { Text("Model") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    "Language",
                    color = Color.White,
                    modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    LanguageChip("English", draft.language == "en") { draft = draft.copy(language = "en") }
                    LanguageChip("हिन्दी / Hinglish", draft.language == "hi") { draft = draft.copy(language = "hi") }
                }

                Spacer(Modifier.height(8.dp))
                SwitchRow(
                    "Always active",
                    "Keep listening: listen, answer, listen again",
                    draft.alwaysActive
                ) { draft = draft.copy(alwaysActive = it) }
                SwitchRow(
                    "Require \"Hey Anya\"",
                    "In always-active mode, ignore speech that doesn't say Anya",
                    draft.requireWakeWord
                ) { draft = draft.copy(requireWakeWord = it) }
                SwitchRow(
                    "Floating orb",
                    "Shows a draggable orb over other apps",
                    draft.floatingOrb
                ) { draft = draft.copy(floatingOrb = it) }
                SwitchRow(
                    "Care check-ins",
                    "A friendly notification every ~2 hours",
                    draft.careNotifications
                ) { draft = draft.copy(careNotifications = it) }
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(draft) }) { Text("Save", color = Color(0xFF00F0FF)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = Color(0xFFB6C2D6)) }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LanguageChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(selected = selected, onClick = onClick, label = { Text(label) })
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 14.sp)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun AnyaOrb(isListening: Boolean, isThinking: Boolean, level: Float) {
    val transition = rememberInfiniteTransition(label = "orb")
    val pulse by transition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val spin by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            tween(if (isListening) 4000 else if (isThinking) 2500 else 10000, easing = LinearEasing),
            RepeatMode.Restart
        ),
        label = "spin"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        val center = Offset(size.width / 2, size.height / 2)
        val radius = (size.minDimension / 4) * pulse * (1f + level * 0.15f)

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(if (isListening) Color(0x6600F0FF) else Color(0x3300D2FF), Color.Transparent),
                center = center,
                radius = radius * 2.2f
            ),
            radius = radius * 2.2f,
            center = center
        )
        drawCircle(
            color = if (isListening) Color(0xFF00F0FF) else Color(0x6638BDF8),
            radius = radius * 1.5f,
            center = center,
            style = Stroke(width = 2.dp.toPx())
        )
        // Rotating marker on the inner ring so spin speed (listening/thinking) is visible
        val a = Math.toRadians(spin.toDouble())
        drawCircle(
            color = Color(0xFF00F0FF),
            radius = 4.dp.toPx(),
            center = Offset(
                center.x + (radius * 1.25f * kotlin.math.cos(a)).toFloat(),
                center.y + (radius * 1.25f * sin(a)).toFloat()
            )
        )
        drawCircle(
            color = Color(0x440284C7),
            radius = radius * 1.25f,
            center = center,
            style = Stroke(width = 1.5.dp.toPx())
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White, Color(0xFF38BDF8), Color(0xFF0284C7), Color(0xFF0A192F)),
                center = Offset(center.x - radius * 0.2f, center.y - radius * 0.2f),
                radius = radius
            ),
            radius = radius,
            center = center
        )
    }
}

@Composable
fun AudioWaveform(isActive: Boolean, isListening: Boolean, level: Float) {
    val transition = rememberInfiniteTransition(label = "wave")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Restart),
        label = "phase"
    )

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(28.dp)
            .padding(vertical = 4.dp)
    ) {
        val barCount = 28
        val barWidth = 3.dp.toPx()
        val spacing = (size.width - barCount * barWidth) / (barCount - 1)
        val centerY = size.height / 2
        // While listening the bars follow the real mic level; while speaking they just animate.
        val gain = if (isListening) 0.25f + level * 0.75f else 1f

        for (i in 0 until barCount) {
            val dist = abs(i - barCount / 2f) / (barCount / 2f)
            val envelope = 1f - dist * dist
            val ratio = if (isActive) {
                max(0.15f, (sin(phase + i * 0.4f) * 0.5f + 0.5f) * envelope * gain)
            } else {
                0.1f
            }
            val barHeight = ratio * size.height
            drawRoundRect(
                color = if (isListening) Color(0xFF00F0FF) else Color(0xFF38BDF8),
                topLeft = Offset(i * (barWidth + spacing), centerY - barHeight / 2),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(2.dp.toPx())
            )
        }
    }
}

@Composable
fun ChatBubble(message: ChatMessage) {
    val isUser = message.sender == "user"
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 300.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(if (isUser) Color(0xFF0284C7) else Color(0xFF0E1A2F))
                .border(
                    1.dp,
                    if (isUser) Color(0xFF38BDF8) else Color(0xFF1E293B),
                    RoundedCornerShape(16.dp)
                )
                .padding(12.dp)
        ) {
            Text(text = message.text, color = Color.White, fontSize = 14.sp)
        }
    }
}
