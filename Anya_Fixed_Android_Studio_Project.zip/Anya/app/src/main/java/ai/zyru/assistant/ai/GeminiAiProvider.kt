package ai.zyru.assistant.ai

import ai.zyru.assistant.data.DEFAULT_MODEL
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

interface AiProvider {
    /**
     * @param conversationHistory previous turns only (the current [prompt] must NOT be included),
     * as pairs of (sender, text) where sender is "user" or anything else for the assistant.
     */
    suspend fun generateResponse(
        prompt: String,
        conversationHistory: List<Pair<String, String>>,
        languagePreference: String
    ): Result<String>
}

class GeminiAiProvider(
    private val apiKeyProvider: () -> String,
    private val modelProvider: () -> String = { DEFAULT_MODEL }
) : AiProvider {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private val systemInstruction = """
        You are Anya, a warm, witty and sharp personal voice assistant with a futuristic anime-companion personality.
        You understand English, Hindi and Hinglish. Reply in the language the user speaks (or the [Language] hint).
        Keep spoken answers short (1-3 sentences) and natural; no markdown, no emojis, no lists.

        When the user asks for a phone action, add one or more intent markers on their own line(s) at the END of
        your reply. Never read or mention the markers aloud. Supported markers (JSON, double quotes):
        [INTENT: {"action": "OPEN_APP", "target": "YouTube"}]
        [INTENT: {"action": "CALL", "phoneNumber": "9876543210"}]
        [INTENT: {"action": "SMS", "phoneNumber": "9876543210", "message": "text"}]
        [INTENT: {"action": "WHATSAPP", "phoneNumber": "919876543210", "message": "text"}]
        [INTENT: {"action": "FLASHLIGHT", "state": "on"}]   (state: on | off | toggle)
        [INTENT: {"action": "VOLUME", "direction": "up"}]   (direction: up | down)
        [INTENT: {"action": "SETTINGS"}]
        Only use a marker when the user clearly asked for that action. If a phone number is needed but unknown,
        ask the user for it instead of guessing.
    """.trimIndent()

    override suspend fun generateResponse(
        prompt: String,
        conversationHistory: List<Pair<String, String>>,
        languagePreference: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            callGemini(prompt, conversationHistory, languagePreference)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun content(role: String, text: String): JsonObject = JsonObject().apply {
        addProperty("role", role)
        add("parts", JsonArray().apply { add(JsonObject().apply { addProperty("text", text) }) })
    }

    private fun callGemini(
        prompt: String,
        history: List<Pair<String, String>>,
        language: String
    ): Result<String> {
        val apiKey = apiKeyProvider().trim()
        if (apiKey.isBlank()) {
            return Result.failure(
                IllegalStateException("Gemini API key is not set. Open Settings and paste your key.")
            )
        }
        val model = modelProvider().trim().ifBlank { DEFAULT_MODEL }

        val contents = JsonArray()
        // Gemini expects the conversation to start with a user turn.
        var seenUser = false
        for ((sender, text) in history.takeLast(10)) {
            if (text.isBlank() || text.startsWith("⚠")) continue
            val role = if (sender == "user") "user" else "model"
            if (!seenUser && role == "model") continue
            seenUser = true
            contents.add(content(role, text))
        }
        val langName = if (language == "hi") "Hindi/Hinglish" else "English"
        contents.add(content("user", "[Language: $langName]\n$prompt"))

        val body = JsonObject().apply {
            add("contents", contents)
            add("systemInstruction", JsonObject().apply {
                add("parts", JsonArray().apply {
                    add(JsonObject().apply { addProperty("text", systemInstruction) })
                })
            })
        }

        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .header("x-goog-api-key", apiKey) // header, not URL, so the key never lands in logs
            .post(body.toString().toRequestBody(jsonMediaType))
            .build()

        return client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                Result.failure(IOException(friendlyHttpError(response.code, raw, model)))
            } else {
                val text = extractText(raw)
                if (text.isNullOrBlank()) {
                    Result.failure(IOException("Gemini returned an empty reply. Try rephrasing."))
                } else {
                    Result.success(text)
                }
            }
        }
    }

    private fun extractText(raw: String): String? {
        val root = JsonParser.parseString(raw).asJsonObject
        val candidates = root.getAsJsonArray("candidates") ?: return null
        if (candidates.size() == 0) return null
        val content = candidates[0].asJsonObject.getAsJsonObject("content") ?: return null
        val parts = content.getAsJsonArray("parts") ?: return null
        val sb = StringBuilder()
        for (p in parts) {
            val t = p.asJsonObject.get("text")
            if (t != null && t.isJsonPrimitive) sb.append(t.asString)
        }
        return sb.toString().trim()
    }

    private fun friendlyHttpError(code: Int, raw: String, model: String): String {
        val apiMessage = try {
            JsonParser.parseString(raw).asJsonObject
                .getAsJsonObject("error")?.get("message")?.asString
        } catch (e: Exception) {
            null
        }
        val hint = when (code) {
            400 -> "Bad request (check your API key)."
            401, 403 -> "API key rejected. Check it in Settings."
            404 -> "Model '$model' not found. Change the model name in Settings."
            429 -> "Rate limit reached. Wait a bit and try again."
            in 500..599 -> "Gemini service is having trouble. Try again soon."
            else -> "Request failed."
        }
        return "$hint (HTTP $code)" + (apiMessage?.let { ": $it" } ?: "")
    }
}
