package ai.zyru.assistant.service

import ai.zyru.assistant.MainActivity
import ai.zyru.assistant.R
import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/** Posts a friendly check-in notification. Scheduled every ~2 hours via WorkManager. */
class CareReminderWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        CareNotifier.show(applicationContext)
        return Result.success()
    }
}

object CareReminderScheduler {
    private const val WORK_NAME = "anya_care_checkin"

    fun update(context: Context, enabled: Boolean) {
        val wm = WorkManager.getInstance(context.applicationContext)
        if (enabled) {
            val request = PeriodicWorkRequestBuilder<CareReminderWorker>(2, TimeUnit.HOURS)
                .setInitialDelay(2, TimeUnit.HOURS)
                .build()
            wm.enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
        } else {
            wm.cancelUniqueWork(WORK_NAME)
        }
    }
}

object CareNotifier {
    private const val CHANNEL_ID = "anya_care_channel"
    private const val NOTIFICATION_ID = 202

    private val messages = listOf(
        "Hey, it's Anya. Have you had some water? Take a small break.",
        "Quick check-in: how are you feeling right now?",
        "Time to stretch your shoulders and rest your eyes for a minute.",
        "Aapne kuch khaya? Apna khayal rakhna, main yahin hu.",
        "Thoda paani pi lo aur gehri saans lo. Anya yaad dila rahi hai."
    )

    fun show(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, context.getString(R.string.notif_channel_care), NotificationManager.IMPORTANCE_DEFAULT
            )
            (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
        val pi = PendingIntent.getActivity(
            context, 1, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val text = messages.random()
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle("Anya")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
        } catch (e: SecurityException) {
        }
    }
}
