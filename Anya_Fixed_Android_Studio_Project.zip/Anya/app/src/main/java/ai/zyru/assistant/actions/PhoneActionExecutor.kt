package ai.zyru.assistant.actions

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings

data class ActionResult(val success: Boolean, val message: String)

/** Executes phone actions requested by the AI. Must be used from the main thread. */
class PhoneActionExecutor(context: Context) {

    private val context = context.applicationContext
    private val cameraManager = this.context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
    private val audioManager = this.context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    private val torchStates = mutableMapOf<String, Boolean>()
    private val torchCallback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            torchStates[cameraId] = enabled
        }
    }

    init {
        try {
            cameraManager?.registerTorchCallback(torchCallback, Handler(Looper.getMainLooper()))
        } catch (e: Exception) {
            // no camera service available
        }
    }

    fun release() {
        try {
            cameraManager?.unregisterTorchCallback(torchCallback)
        } catch (e: Exception) {
        }
    }

    fun execute(intent: PhoneIntent): ActionResult = try {
        when (intent.action.trim().uppercase()) {
            "OPEN_APP" -> openApp(intent.params["target"].orEmpty())
            "CALL" -> dial(intent.params["phoneNumber"].orEmpty())
            "SMS" -> sms(intent.params["phoneNumber"].orEmpty(), intent.params["message"].orEmpty())
            "WHATSAPP" -> whatsApp(intent.params["phoneNumber"].orEmpty(), intent.params["message"].orEmpty())
            "FLASHLIGHT" -> flashlight(intent.params["state"].orEmpty())
            "VOLUME" -> volume(intent.params["direction"].orEmpty())
            "SETTINGS" -> {
                start(Intent(Settings.ACTION_SETTINGS))
                ActionResult(true, "Opening settings.")
            }
            else -> ActionResult(false, "I don't know how to do '${intent.action}'.")
        }
    } catch (e: ActivityNotFoundException) {
        ActionResult(false, "No app on this phone can handle that.")
    } catch (e: SecurityException) {
        ActionResult(false, "Android blocked that action (permission missing).")
    } catch (e: Exception) {
        ActionResult(false, "That action failed: ${e.localizedMessage ?: "unknown error"}")
    }

    private fun start(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    // ---- Flashlight -------------------------------------------------------------------------

    private fun torchCameraId(): String? {
        val cm = cameraManager ?: return null
        val withFlash = cm.cameraIdList.filter { id ->
            cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
        return withFlash.firstOrNull { id ->
            cm.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING) ==
                CameraCharacteristics.LENS_FACING_BACK
        } ?: withFlash.firstOrNull()
    }

    private fun flashlight(state: String): ActionResult {
        val id = torchCameraId() ?: return ActionResult(false, "This phone has no flashlight.")
        val current = torchStates[id] ?: false
        val enable = when (state.trim().lowercase()) {
            "on", "true", "enable" -> true
            "off", "false", "disable" -> false
            else -> !current
        }
        cameraManager?.setTorchMode(id, enable)
        return ActionResult(true, if (enable) "Flashlight on." else "Flashlight off.")
    }

    // ---- Calls / messages -------------------------------------------------------------------

    private fun cleanNumber(raw: String): String = raw.filter { it.isDigit() || it == '+' }

    private fun dial(raw: String): ActionResult {
        val number = cleanNumber(raw)
        if (number.length < 3) return ActionResult(false, "I need a valid phone number to call.")
        // ACTION_DIAL opens the dialer pre-filled; the user presses call (no CALL_PHONE permission needed).
        start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
        return ActionResult(true, "Opening the dialer for $number.")
    }

    private fun sms(raw: String, message: String): ActionResult {
        val number = cleanNumber(raw)
        if (number.length < 3) return ActionResult(false, "I need a valid phone number for the SMS.")
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).putExtra("sms_body", message)
        start(i)
        return ActionResult(true, "Message ready to send.")
    }

    private fun whatsApp(raw: String, message: String): ActionResult {
        var digits = raw.filter { it.isDigit() }
        if (digits.length == 10) digits = "91$digits" // assume India when no country code is given
        val url = if (digits.length >= 8) {
            "https://wa.me/$digits?text=${Uri.encode(message)}"
        } else {
            return openApp("whatsapp")
        }
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try {
                start(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(pkg))
                return ActionResult(true, "Opening WhatsApp.")
            } catch (e: ActivityNotFoundException) {
                // try next package
            }
        }
        return ActionResult(false, "WhatsApp is not installed on this phone.")
    }

    // ---- Apps / system ----------------------------------------------------------------------

    private val knownApps = mapOf(
        "youtube" to "com.google.android.youtube",
        "whatsapp" to "com.whatsapp",
        "chrome" to "com.android.chrome",
        "instagram" to "com.instagram.android",
        "facebook" to "com.facebook.katana",
        "telegram" to "org.telegram.messenger",
        "spotify" to "com.spotify.music",
        "gmail" to "com.google.android.gm",
        "maps" to "com.google.android.apps.maps",
        "google maps" to "com.google.android.apps.maps",
        "play store" to "com.android.vending",
        "photos" to "com.google.android.apps.photos",
        "netflix" to "com.netflix.mediaclient",
        "twitter" to "com.twitter.android",
        "x" to "com.twitter.android",
        "snapchat" to "com.snapchat.android",
        "paytm" to "net.one97.paytm",
        "phonepe" to "com.phonepe.app",
        "google pay" to "com.google.android.apps.nbu.paisa.user"
    )

    private fun openApp(target: String): ActionResult {
        val key = target.trim().lowercase()
        if (key.isEmpty()) return ActionResult(false, "Which app should I open?")

        when (key) {
            "camera" -> {
                start(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
                return ActionResult(true, "Opening camera.")
            }
            "settings" -> {
                start(Intent(Settings.ACTION_SETTINGS))
                return ActionResult(true, "Opening settings.")
            }
            "phone", "dialer" -> {
                start(Intent(Intent.ACTION_DIAL))
                return ActionResult(true, "Opening the dialer.")
            }
        }

        val pkg = knownApps[key]
            ?: (if (key.contains('.') && !key.contains(' ')) key else null)
            ?: findPackageByLabel(key)
            ?: return ActionResult(false, "I couldn't find an app called $target.")

        val launch = context.packageManager.getLaunchIntentForPackage(pkg)
            ?: return ActionResult(false, "$target isn't installed on this phone.")
        start(launch)
        return ActionResult(true, "Opening $target.")
    }

    private fun findPackageByLabel(label: String): String? {
        val pm = context.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val apps = pm.queryIntentActivities(main, 0)
        val match = apps.firstOrNull { it.loadLabel(pm).toString().equals(label, ignoreCase = true) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().contains(label, ignoreCase = true) }
        return match?.activityInfo?.packageName
    }

    private fun volume(direction: String): ActionResult {
        val am = audioManager ?: return ActionResult(false, "Can't reach the audio system.")
        val up = direction.trim().lowercase().let { it == "up" || it == "raise" || it == "increase" }
        am.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI
        )
        return ActionResult(true, if (up) "Volume up." else "Volume down.")
    }
}
