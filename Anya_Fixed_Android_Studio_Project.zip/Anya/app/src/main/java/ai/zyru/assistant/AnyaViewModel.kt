package ai.zyru.assistant

import ai.zyru.assistant.actions.IntentParser
import ai.zyru.assistant.actions.PhoneActionExecutor
import ai.zyru.assistant.ai.GeminiAiProvider
import ai.zyru.assistant.data.AnyaSettings
import ai.zyru.assistant.data.SettingsStore
import ai.zyru.assistant.service.AnyaVoiceService
import ai.zyru.assistant.service.CareReminderScheduler
import ai.zyru.assistant.service.FloatingOrbService
import android.app.Application
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

private val idGenerator = AtomicLong()

data class ChatMessage(
    val sender: String, // "user" or "anya"
    val text: String,
    val id: Long = idGenerator.incrementAndGet()
)

data class AnyaUiState(
    val isListening: Boolean = false,
    val isSpeaking: Boolean = false,
    val isThinking: Boolean = false,
    /** 0..1 microphone level, drives the waveform while listening. */
    val audioLevel: Float = 0f,
    val messages: List<ChatMessage> = emptyList(),
    val settings: AnyaSettings = AnyaSettings()
)

class AnyaViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    private val app: Application = application
    private val store = SettingsStore(application)
    private val executor = PhoneActionExecutor(application)
    private val mainHandler = Handler(Looper.getMainLooper())

    private val _uiState = MutableStateFlow(
        AnyaUiState(
            settings = store.load(),
            messages = listOf(
                ChatMessage(
                    "anya",
                    "Hi, I'm Anya! Add your Gemini API key in Settings, then tap the orb or type to talk to me."
                )
            )
        )
    )
    val uiState: StateFlow<AnyaUiState> = _uiState.asStateFlow()

    private val aiProvider = GeminiAiProvider(
        apiKeyProvider = { _uiState.value.settings.apiKey },
        modelProvider = { _uiState.value.settings.model }
    )

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var warnedMissingHindiVoice = false
    private var requestJob: Job? = null

    /** True while the continuous listen -> think -> speak -> listen loop is running. */
    private var loopActive = false

    init {
        tts = TextToSpeech(app, this)
        CareReminderScheduler.update(app, _uiState.value.settings.careNotifications)
        syncFloatingOrb(_uiState.value.settings.floatingOrb)
    }

    // ---------------------------------------------------------------------------------------
    // Text to speech
    // ---------------------------------------------------------------------------------------

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        ttsReady = true
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                _uiState.update { it.copy(isSpeaking = true) }
            }

            override fun onDone(utteranceId: String?) = onSpeechFinished()

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) = onSpeechFinished()
        })
        applyTtsLanguage()
    }

    private fun applyTtsLanguage() {
        val engine = tts ?: return
        val wantHindi = _uiState.value.settings.language == "hi"
        val locale = if (wantHindi) Locale("hi", "IN") else Locale.US
        val result = engine.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.setLanguage(Locale.US)
            if (wantHindi && !warnedMissingHindiVoice) {
                warnedMissingHindiVoice = true
                addMessage(
                    "anya",
                    "Hindi voice data isn't installed on this phone, so I'll speak with the English voice. " +
                        "Install it from Android Settings > Text-to-speech output."
                )
            }
        }
    }

    private fun speak(text: String) {
        val cleaned = text.replace(Regex("[*_`#]"), "").trim()
        if (!ttsReady || cleaned.isEmpty()) {
            onSpeechFinished()
            return
        }
        // TextToSpeech has a max input length (~4000 chars).
        val toSpeak = if (cleaned.length > 3500) cleaned.take(3500) else cleaned
        val code = tts?.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null, "anya_${System.nanoTime()}")
        if (code != TextToSpeech.SUCCESS) onSpeechFinished()
    }

    private fun onSpeechFinished() {
        _uiState.update { it.copy(isSpeaking = false) }
        mainHandler.post { continueLoopIfNeeded(0) }
    }

    fun stopSpeaking() {
        tts?.stop()
        _uiState.update { it.copy(isSpeaking = false) }
    }

    // ---------------------------------------------------------------------------------------
    // Speech recognition
    // ---------------------------------------------------------------------------------------

    private val wakeWordRegex =
        Regex("(?i)\\b(hey |hi |ok |okay )?(anya|aanya|ania|annya)\\b[,.!? ]*|(ए |हे )?(अन्या|आन्या|अनिया)[,.!? ]*")

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            _uiState.update { it.copy(isListening = true) }
        }

        override fun onRmsChanged(rmsdB: Float) {
            val target = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
            _uiState.update { it.copy(audioLevel = it.audioLevel * 0.6f + target * 0.4f) }
        }

        override fun onResults(results: Bundle?) {
            _uiState.update { it.copy(isListening = false, audioLevel = 0f) }
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                .orEmpty()
            handleRecognizedText(text)
        }

        override fun onError(error: Int) {
            _uiState.update { it.copy(isListening = false, audioLevel = 0f) }
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                    continueLoopIfNeeded(800)

                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    speechRecognizer?.cancel()
                    continueLoopIfNeeded(1500)
                }

                SpeechRecognizer.ERROR_CLIENT -> Unit // we cancelled it ourselves

                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    loopActive = false
                    addMessage("anya", "I need microphone permission to hear you.")
                }

                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                SpeechRecognizer.ERROR_SERVER -> {
                    addMessage("anya", "Voice recognition needs an internet connection right now.")
                    continueLoopIfNeeded(4000)
                }

                else -> {
                    addMessage("anya", "Voice recognition error ($error).")
                    continueLoopIfNeeded(4000)
                }
            }
        }

        override fun onBeginningOfSpeech() {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    /** Caller must hold RECORD_AUDIO. Must run on the main thread. */
    fun startVoiceListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(app)) {
            loopActive = false
            addMessage("anya", "Speech recognition isn't available on this phone (install/enable Google app).")
            return
        }
        if (_uiState.value.isThinking) return
        tts?.stop()
        _uiState.update { it.copy(isSpeaking = false, isListening = true) }

        speechRecognizer?.destroy()
        val recognizer = SpeechRecognizer.createSpeechRecognizer(app)
        recognizer.setRecognitionListener(recognitionListener)
        speechRecognizer = recognizer

        val tag = if (_uiState.value.settings.language == "hi") "hi-IN" else "en-IN"
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        recognizer.startListening(intent)
    }

    /** User stopped listening: also pauses the always-active loop until they tap again. */
    fun stopVoiceListening() {
        loopActive = false
        mainHandler.removeCallbacksAndMessages(null)
        speechRecognizer?.cancel()
        _uiState.update { it.copy(isListening = false, audioLevel = 0f) }
    }

    /** Orb / mic button. Caller must hold RECORD_AUDIO. */
    fun toggleListening() {
        val s = _uiState.value
        if (s.isListening) {
            stopVoiceListening()
        } else {
            if (s.settings.alwaysActive) loopActive = true
            startVoiceListening()
        }
    }

    private fun continueLoopIfNeeded(delayMs: Long) {
        mainHandler.postDelayed({
            val s = _uiState.value
            if (loopActive && s.settings.alwaysActive && !s.isListening && !s.isThinking && !s.isSpeaking) {
                startVoiceListening()
            }
        }, delayMs)
    }

    private fun handleRecognizedText(raw: String) {
        var text = raw.trim()
        if (text.isEmpty()) {
            continueLoopIfNeeded(300)
            return
        }
        val s = _uiState.value.settings
        if (s.alwaysActive && s.requireWakeWord) {
            val match = wakeWordRegex.find(text)
            if (match == null) {
                continueLoopIfNeeded(300) // not addressed to Anya: ignore
                return
            }
            text = text.removeRange(match.range).trim()
            if (text.isEmpty()) {
                val reply = "Yes? I'm listening."
                addMessage("anya", reply)
                speak(reply)
                return
            }
        }
        sendMessage(text)
    }

    // ---------------------------------------------------------------------------------------
    // Chat
    // ---------------------------------------------------------------------------------------

    fun sendMessage(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return

        val history = _uiState.value.messages.takeLast(10).map { it.sender to it.text }
        tts?.stop()
        _uiState.update {
            it.copy(
                messages = it.messages + ChatMessage("user", text),
                isThinking = true,
                isSpeaking = false
            )
        }

        requestJob?.cancel()
        requestJob = viewModelScope.launch {
            val language = _uiState.value.settings.language
            val result = aiProvider.generateResponse(text, history, language)
            _uiState.update { it.copy(isThinking = false) }
            result.fold(
                onSuccess = { reply -> handleReply(reply) },
                onFailure = { error ->
                    addMessage("anya", error.localizedMessage ?: "Something went wrong.")
                    continueLoopIfNeeded(5000)
                }
            )
        }
    }

    private fun handleReply(reply: String) {
        val parsed = IntentParser.extract(reply)
        val outcomes = parsed.intents.map { executor.execute(it) }
        val failures = outcomes.filter { !it.success }

        val spoken = parsed.text.ifBlank {
            if (outcomes.isNotEmpty() && failures.isEmpty()) "Done." else ""
        }
        if (spoken.isNotBlank()) addMessage("anya", spoken)
        failures.forEach { addMessage("anya", "⚠ ${it.message}") }

        val toSpeak = failures.firstOrNull()?.message ?: spoken
        speak(toSpeak)
    }

    private fun addMessage(sender: String, text: String) {
        _uiState.update { it.copy(messages = it.messages + ChatMessage(sender, text)) }
    }

    // ---------------------------------------------------------------------------------------
    // Settings / background features
    // ---------------------------------------------------------------------------------------

    fun saveSettings(new: AnyaSettings) {
        val old = _uiState.value.settings
        store.save(new)
        _uiState.update { it.copy(settings = new) }

        if (new.language != old.language) applyTtsLanguage()
        if (new.careNotifications != old.careNotifications) {
            CareReminderScheduler.update(app, new.careNotifications)
        }
        if (new.floatingOrb != old.floatingOrb) syncFloatingOrb(new.floatingOrb)

        if (new.alwaysActive && !old.alwaysActive) {
            resumeAlwaysActive()
        } else if (!new.alwaysActive && old.alwaysActive) {
            loopActive = false
            stopVoiceListening()
            app.stopService(Intent(app, AnyaVoiceService::class.java))
        }
    }

    /** Start the always-active loop (UI calls this on launch when enabled and mic is granted). */
    fun resumeAlwaysActive() {
        if (!_uiState.value.settings.alwaysActive || loopActive) return
        loopActive = true
        try {
            ContextCompat.startForegroundService(app, Intent(app, AnyaVoiceService::class.java))
        } catch (e: Exception) {
            // Foreground service couldn't start; the loop still works while the app is open.
        }
        if (!_uiState.value.isListening) startVoiceListening()
    }

    private fun syncFloatingOrb(enabled: Boolean) {
        val intent = Intent(app, FloatingOrbService::class.java)
        if (enabled && Settings.canDrawOverlays(app)) {
            try {
                app.startService(intent)
            } catch (e: Exception) {
            }
        } else {
            app.stopService(intent)
        }
    }

    override fun onCleared() {
        loopActive = false
        mainHandler.removeCallbacksAndMessages(null)
        requestJob?.cancel()
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        executor.release()
        app.stopService(Intent(app, AnyaVoiceService::class.java))
        super.onCleared()
    }
}
