package ai.zyru.assistant.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AnyaColors = darkColorScheme(
    primary = Color(0xFF00F0FF),
    onPrimary = Color.Black,
    secondary = Color(0xFF38BDF8),
    onSecondary = Color.Black,
    background = Color(0xFF050811),
    onBackground = Color.White,
    surface = Color(0xFF0E1A2F),
    onSurface = Color.White,
    surfaceVariant = Color(0xFF0E223D),
    onSurfaceVariant = Color(0xFFB6C2D6)
)

@Composable
fun AnyaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AnyaColors, content = content)
}
