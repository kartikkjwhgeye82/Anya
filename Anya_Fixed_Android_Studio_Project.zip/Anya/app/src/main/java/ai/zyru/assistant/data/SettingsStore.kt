package ai.zyru.assistant.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

const val DEFAULT_MODEL = "gemini-2.5-flash"

data class AnyaSettings(
    val apiKey: String = "",
    val model: String = DEFAULT_MODEL,
    /** "en" or "hi" */
    val language: String = "en",
    val alwaysActive: Boolean = false,
    val requireWakeWord: Boolean = false,
    val floatingOrb: Boolean = false,
    val careNotifications: Boolean = false
)

/** Stores the API key in EncryptedSharedPreferences; other settings in normal prefs. */
class SettingsStore(context: Context) {

    private val appContext = context.applicationContext
    private val plain: SharedPreferences =
        appContext.getSharedPreferences("anya_prefs", Context.MODE_PRIVATE)
    private val secure: SharedPreferences = createSecurePrefs()

    private fun createSecurePrefs(): SharedPreferences = try {
        val masterKey = MasterKey.Builder(appContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            appContext,
            "anya_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        // Keystore can be broken on some devices; fall back so the app still works.
        appContext.getSharedPreferences("anya_secure_fallback", Context.MODE_PRIVATE)
    }

    fun load(): AnyaSettings = AnyaSettings(
        apiKey = secure.getString("api_key", "") ?: "",
        model = plain.getString("model", DEFAULT_MODEL)?.ifBlank { DEFAULT_MODEL } ?: DEFAULT_MODEL,
        language = plain.getString("language", "en") ?: "en",
        alwaysActive = plain.getBoolean("always_active", false),
        requireWakeWord = plain.getBoolean("require_wake_word", false),
        floatingOrb = plain.getBoolean("floating_orb", false),
        careNotifications = plain.getBoolean("care_notifications", false)
    )

    fun save(s: AnyaSettings) {
        secure.edit().putString("api_key", s.apiKey.trim()).apply()
        plain.edit()
            .putString("model", s.model.trim().ifBlank { DEFAULT_MODEL })
            .putString("language", s.language)
            .putBoolean("always_active", s.alwaysActive)
            .putBoolean("require_wake_word", s.requireWakeWord)
            .putBoolean("floating_orb", s.floatingOrb)
            .putBoolean("care_notifications", s.careNotifications)
            .apply()
    }
}
