# Anya - Native Android Voice Companion

Anya is a voice assistant for Android (8.0+ / API 26-35) built with Kotlin + Jetpack Compose and Google Gemini.
Created by Kartik.

## What it does
- **Voice + text chat** in English, Hindi and Hinglish (speech recognition + text-to-speech, language switch in Settings).
- **Phone actions** requested by voice: open apps by name, open dialer / SMS / WhatsApp pre-filled, flashlight, volume, system settings.
  Calls and messages only open the dialer / compose screen - you always press send/call yourself.
- **Always active mode**: continuous listen -> answer -> listen loop (foreground service keeps it alive). Optional "Hey Anya" filter.
- **Lock-screen aware**: the app shows over the lock screen and wakes the display when opened.
- **Floating orb**: draggable overlay (needs "Display over other apps" permission).
- **Care check-ins**: friendly notification roughly every 2 hours (opt-in).
- API key is stored encrypted (EncryptedSharedPreferences) and sent in a request header, not in the URL.

## Setup
1. Get a free key at https://aistudio.google.com/apikey
2. Build and install (below), open Anya, paste the key in Settings. Default model is `gemini-2.5-flash`; change it in Settings if Google retires it.

## Build
```bash
./gradlew assembleDebug
adb install app/build/outputs/apk/debug/app-debug.apk
```
Or push to GitHub: the workflow in `.github/workflows/build-apk.yml` builds the APK and uploads it as an artifact.

## Known limits
- Speech recognition uses Android's built-in recognizer (usually needs internet).
- There is no true offline wake-word detection; "Hey Anya" works by filtering what the recognizer hears while always-active mode is on.
- Starting other apps from the background can be blocked by Android 10+; actions work reliably while Anya is on screen.
- Hindi speech output needs the Hindi voice installed in Android's text-to-speech settings.
